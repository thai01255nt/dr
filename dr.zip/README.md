export ROS_MASTER_URI=http://:11311
export ROS_HOSTNAME=
